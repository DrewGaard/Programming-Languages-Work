Project 5 Hunt the Wumpus Extra Credit

For extra credit I added a reload tile to the board that if the user lands on they
will get another arrow that they can use against the wumpus. They can also see how
many arrows they have by pressing 'i' during the game to see their inventory.