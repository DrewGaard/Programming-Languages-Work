WPMain is the main file that should run first.

I made a text editor program which has multiple features.
I included a .jar of the program aswell so it can be run without eclipse.

-To exit the program since there is no X button go to the menubar and choose file -> exit

Main Aspects of the Application
-Can load a .txt file and edit it
-Can save what has been typed into the textbox
-Can clear the text window
-Can change font style
-Can change text color
-can change textArea background color
-has a built in calculator so the user can perform simple computations
-feature to load in the text size from the last time the program was closed

For extra credit I made the window transparent so that the user has the ability to see their webbrowser for example while they type. The window can be moved by dragging the menu bar.


