//Drew Overgaard
//Just a simple calculator to add to my text editor program for COMP 141
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Calc extends JFrame {
	
	static JFrame frame2 = new JFrame("Calc");
	private static JButton plus;
	private static JButton minus;
	private static JButton multiply;
	private static JButton divide;
	private static JTextField input1;
	private static JTextField input2;
	
	
	
	public Calc() {	
		
		//frame.setResizable(false);
		//frame2.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		//frame.setLayout(new FlowLayout());
		
		frame2.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		frame2.setResizable(false);
		
		
		
		JMenuBar menubar = new JMenuBar();
		frame2.setJMenuBar(menubar);
		
		JMenu help = new JMenu("Help");
		menubar.add(help);
		JMenuItem about = new JMenuItem("About");
		help.add(about);
		
		
		GridLayout buttonPanel = new GridLayout(0, 2);        
		
		frame2.setLayout(buttonPanel);
		
		//Creating the buttons and the textbox
		plus = new JButton("+");
		minus = new JButton("-");
		multiply = new JButton ("*");
		divide = new JButton("/");
		input1 = new JTextField(10);
		input2 = new JTextField(10);
		input1.setEditable(true);
		input2.setEditable(true);
		
		
		Font startingFont = new Font("Monospace", Font.PLAIN, 22);
		input1.setFont(startingFont);
		input2.setFont(startingFont);
		
		//Add the buttons and textbox to the screen
		frame2.add(input1);
		frame2.add(input2);
		frame2.add(minus);
		frame2.add(plus);
		frame2.add(multiply);
		frame2.add(divide);
		frame2.setSize(400, 200);
	
		frame2.getRootPane().setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
		
		
		frame2.setUndecorated(true);
		frame2.setOpacity(0.9f);
		//This is used to allow the user to move the transparent frame
		ComponentMover cr = new ComponentMover();
		cr.registerComponent(frame2);
		cr.setSnapSize(new Dimension(10, 10));
		
		//Start the frame in the middle of the screen
	    frame2.setLocationRelativeTo(null);
		
		
		frame2.setVisible(true);
		
		class aboutDialog implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				JOptionPane.showMessageDialog(frame2, "The calculator portion of the application stays open unil the main window is closed by selecting 'Exit'", "About", JOptionPane.INFORMATION_MESSAGE);
		    }
		}
		
		class plusAction implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				try{
					double value1 = Double.parseDouble(input1.getText());
					double value2 = Double.parseDouble(input2.getText());
					double total = value1 + value2;
					input2.setText("" + total);
				}
				catch(NumberFormatException e1)
				{
					
				}
			}
		}
		
		class minusAction implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				try{
					double value1 = Double.parseDouble(input1.getText());
					double value2 = Double.parseDouble(input2.getText());
					double total = value1 - value2;
					input2.setText("" + total);
				}
				catch(NumberFormatException e1)
				{
					
				}
			}
		}
		
		class multiplyAction implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				try{
					double value1 = Double.parseDouble(input1.getText());
					double value2 = Double.parseDouble(input2.getText());
					double total = value1 * value2;
					input2.setText("" + total);
				}
				catch(NumberFormatException e1)
				{
					
				}
			}
		}
		
		class divideAction implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				try{
					double value1 = Double.parseDouble(input1.getText());
					double value2 = Double.parseDouble(input2.getText());
					double total = value1 / value2;
					input2.setText("" + total);
				}
				catch(NumberFormatException e1)
				{
					
				}
			}
		}
		
		plus.addActionListener(new plusAction());
		minus.addActionListener(new minusAction());
		multiply.addActionListener(new multiplyAction());
		divide.addActionListener(new divideAction());
		about.addActionListener(new aboutDialog());
	
	}
}
