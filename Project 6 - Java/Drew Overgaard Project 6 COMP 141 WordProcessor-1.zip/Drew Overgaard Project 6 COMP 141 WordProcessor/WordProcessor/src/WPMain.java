//Created by Drew Overgaard for COMP 141 Programming Languages Course

import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.awt.*;

public class WPMain {
	public static String fontName;
	public static int fontSize;
	
	public static void main (String[] args) {		
		JFrame frame = new JFrame("SimpleTxt");
		frame.setSize(800, 600);
		//frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		//Create a menubar
		JMenuBar menubar = new JMenuBar();
		frame.setJMenuBar(menubar);
		
		//This handles the labels for the file portion of the menu bar
		JMenu file = new JMenu("File");
		menubar.add(file);
		JMenuItem copy = new JMenuItem("Copy");
		file.add(copy);
		JMenuItem clear = new JMenuItem("Clear");
		file.add(clear);
		JMenuItem load = new JMenuItem("Load");
		file.add(load);
		JMenuItem save = new JMenuItem("Save");
		file.add(save);
		JMenuItem exit = new JMenuItem("Exit");
		file.add(exit);
		
		//This handles the labels for the help portion of the menu bar
		JMenu help = new JMenu("Help");
		menubar.add(help);
		JMenuItem about = new JMenuItem("About");
		help.add(about);
		
		//This handles the labels for the font portion of the menu bar
		JMenu font = new JMenu("Font");
		menubar.add(font);
		JMenuItem monospaced = new JMenuItem("Monospaced");
		font.add(monospaced);
		JMenuItem serif = new JMenuItem("Serif");
		font.add(serif);
		JMenuItem dialog = new JMenuItem("Dialog");
		font.add(dialog);
		
		//This handles the labels for the background portion of the menu bar
		JMenu color = new JMenu("Background Color");
		menubar.add(color);
		JMenuItem white = new JMenuItem("White");
		color.add(white);
		JMenuItem gray = new JMenuItem("Gray");
		color.add(gray);
		JMenuItem blue = new JMenuItem("Blue");
		color.add(blue);
		JMenuItem red = new JMenuItem("Red");
		color.add(red);
		
		//This handles the labels for the font color portion of the menu bar
		JMenu fontColor = new JMenu("Font Color");
		menubar.add(fontColor);
		JMenuItem whiteFont = new JMenuItem("White");
		fontColor.add(whiteFont);
		JMenuItem redFont = new JMenuItem("Red");
		fontColor.add(redFont);
		JMenuItem grayFont = new JMenuItem("Gray");
		fontColor.add(grayFont);
		
		
		//This handles the labels for the text size portion of the menu bar
		JMenu text = new JMenu("Text");
		menubar.add(text);
		JMenuItem textSize = new JMenuItem("Text Size");
		text.add(textSize);
		
		//This handles the labels for the calculator portion of the menu bar
		JMenu calc = new JMenu("Calculator");
		menubar.add(calc);
		JMenuItem openCalc = new JMenuItem("Open");
		calc.add(openCalc);
		
		
		//This handles the labels for the format portion of the menu bar
		JMenu format = new JMenu("Format");
		menubar.add(format);
		JMenuItem loadFormat = new JMenuItem("Load Format");
		format.add(loadFormat);
		
		//Transparent
		frame.setUndecorated(true);
		frame.setOpacity(0.9f);
		
		//This is used to allow the user to move the transparent frame
		ComponentMover cr = new ComponentMover();
		cr.registerComponent(frame);
		cr.setSnapSize(new Dimension(10, 10));
		
		
		//Set the border line width and set the color to black
		frame.getRootPane().setBorder(BorderFactory.createMatteBorder(1, 1, 1, 1, Color.BLACK));
		
		//frame.setLayout(new BorderLayout());
				
		//Add the textArea here
		JTextArea textBox = new JTextArea(200, 1000);
		textBox.setPreferredSize(new Dimension(20, 10));
		textBox.setSelectedTextColor(Color.green);
		textBox.setLineWrap(true);
		textBox.setWrapStyleWord(true);
		
		
		//Makes sure only the verticle scroll bar is present
		JScrollPane scroll = new JScrollPane(textBox, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		frame.add(scroll);
		
		//textBox.setEditable(true);
		//textBox.
		
		/*
		JButton largerFont = new JButton("+Font");
		largerFont.setPreferredSize(new Dimension(40, 40));
		frame.add(largerFont, BorderLayout.EAST);
		JButton smallerFont = new JButton("-Font");
		//frame.add(smallerFont, BorderLayout.AFTER_LAST_LINE);
		 */

		//Default font and size specified here
		fontName = "Serif";
		fontSize = 22;
		Font startingFont = new Font(fontName, Font.PLAIN, fontSize);
		textBox.setFont(startingFont);
		
		//Start the frame in the middle of the screen
	    frame.setLocationRelativeTo(null);
	    
		//Set the frame and contents to visible
		frame.setVisible(true);
		
		//Here are all the action listeners for the menubar
		
		//Handles the exit option
		class exitaction implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				System.exit(0);
			}
		}
		
		//Handles the gray background option
		class grayBackground implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				textBox.setBackground(Color.gray);
			}
		}
		
		//Handles the calculator option
		class newCalc implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				Calc newCalc = new Calc();
				newCalc.removeAll();
			}
		}
		
		//Handles the red background option
		class redBackground implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				textBox.setBackground(Color.red);
			}
		}
		
		//Handles saving the text in the textArea to a file specified by the user
		class saveText implements ActionListener {
			public void actionPerformed (ActionEvent e) {

				BufferedWriter writer;
		        try {
		        	String response = JOptionPane.showInputDialog(null, "Enter the desired file name.", "", JOptionPane.YES_NO_OPTION);
		        	if((response != null) && (response.length() > 0))
		        	{
			            writer = new BufferedWriter(new FileWriter(response+".txt",
			                    false));
			            textBox.write(writer);
			            writer.close();
			            JOptionPane.showMessageDialog(null, "File has been saved","File Saved",JOptionPane.INFORMATION_MESSAGE);
			            // true for rewrite, false for override
		        	}

		        } catch (IOException e3) {
		            JOptionPane.showMessageDialog(null, "Error Occured");
		            e3.printStackTrace();
		        }
		    }				
		}
		
		//Loads a file specified by the user
		class loadText implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				JFileChooser chooser = new JFileChooser();
				chooser.showOpenDialog(null);
				File f = chooser.getSelectedFile();
				try
				{
					String filename = f.getAbsolutePath();
				
				//https://www.youtube.com/watch?v=T_T9U8Djles
					FileReader reader = new FileReader(filename);
					BufferedReader br = new BufferedReader(reader);
					textBox.read(br, null);
					br.close();
					textBox.requestFocus();
				}
				catch(Exception e1) {
					JOptionPane.showMessageDialog(null,"No file specified.");
				}
			}
		}
		
		//Handles the white background option
		class whiteBackground implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				textBox.setBackground(Color.white);
			}
		}
		
		//Handles clearing the textArea
		class clearText implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				textBox.setText("");
			}
		}
		
		//Handles the red font option
		class redFont implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				textBox.setForeground(Color.red);
			}
		}
		//Handles the white font option
		class whiteFont implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				textBox.setForeground(Color.white);
			}
		}
		
		//Handles the gray font option
		class grayFont implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				textBox.setForeground(Color.gray);
			}
		}
		
		//Handles the blue background option
		class blueBackground implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				textBox.setBackground(Color.blue);
			}
		}
		
		//Handles the monospaced font option
		class fontStyleMono implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				fontName = "Monospaced";
				Font mono = new Font(fontName, Font.PLAIN, fontSize);
				textBox.setFont(mono);
			}
		}
		
		//Handles the option to copy selected text in the text area
		class copyText implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				textBox.copy();
			}
		}
		
		//Handles the serif font option
		class fontStyleSerif implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				fontName = "Serif";
				Font serif = new Font(fontName, Font.PLAIN, fontSize);
				textBox.setFont(serif);
			}
		}
		
		//Handles the dialog font option
		class fontStyleDialog implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				fontName = "Dialog";
				Font dialog = new Font(fontName, Font.PLAIN, fontSize);
				textBox.setFont(dialog);
			}
		}
		
		/*
		class largerSize implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				fontSize = fontSize + 2;
				Font larger = new Font(fontName, Font.PLAIN, fontSize);
				textBox.setFont(larger);
			}
		}
		
		class smallerSize implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				fontSize = fontSize - 2;
				Font larger = new Font(fontName, Font.PLAIN, fontSize);
				textBox.setFont(larger);
			}
		}
		*/
		
		//Handles the about message
		class aboutDialog implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				JOptionPane.showMessageDialog(frame, "Created by Drew Overgaard.\nSpring 2016 COMP 141.", "About", JOptionPane.INFORMATION_MESSAGE);
		    }
		}
		
		//Handles getting the text size specified by the user
		class textSizeDialog implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				String response = JOptionPane.showInputDialog(null, "Enter the desired text size.", 22);
				
				try
				{
				if((Integer.parseInt(response) > 0) && Integer.parseInt(response) < 100)
					fontSize = Integer.parseInt(response);
					Font larger = new Font(fontName, Font.PLAIN, fontSize);
					textBox.setFont(larger);
					storeText(Integer.toString(fontSize), "fontSize.txt");
				}
				catch(Exception e3)
				{
					
				}
		    }
		}
		
		
		//Loads the file that saves the last used font size
		class loadFormatFile implements ActionListener {
			public void actionPerformed (ActionEvent e) {
				try
				{
					int fontSize = Integer.parseInt(readText("fontSize.txt"));
					Font larger = new Font(fontName, Font.PLAIN, fontSize);
					textBox.setFont(larger);
				}
				catch(Exception e5)
				{
					
				}
		    }
		}
		
		//Assigning the menu options with the correct action listeners
		exit.addActionListener(new exitaction());
		about.addActionListener(new aboutDialog());
		monospaced.addActionListener(new fontStyleMono());
		serif.addActionListener(new fontStyleSerif());
		dialog.addActionListener(new fontStyleDialog());
		//largerFont.addActionListener(new largerSize());
		//smallerFont.addActionListener(new smallerSize());
		gray.addActionListener(new grayBackground());
		white.addActionListener(new whiteBackground());
		blue.addActionListener(new blueBackground());
		red.addActionListener(new redBackground());
		load.addActionListener(new loadText());
		save.addActionListener(new saveText());
		textSize.addActionListener(new textSizeDialog());
		copy.addActionListener(new copyText());
		redFont.addActionListener(new redFont());
		whiteFont.addActionListener(new whiteFont());
		grayFont.addActionListener(new grayFont());
		openCalc.addActionListener(new newCalc());
		clear.addActionListener(new clearText());
		loadFormat.addActionListener(new loadFormatFile());
	}

	//Used to save text to a file
	public static void storeText(String text, String Filename){
		PrintWriter storeText = null;
		try {
			storeText = new PrintWriter(Filename);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		storeText.println(text);
		storeText.close();
	}
	
	//Used to get text from a file
	public static String readText(String Filename){
		String content_in_textbox = null;
		try {
			content_in_textbox = new Scanner(new File(Filename)).useDelimiter("\\Z").next();
			//System.out.println(content);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
		}
		return content_in_textbox;
	}

}


