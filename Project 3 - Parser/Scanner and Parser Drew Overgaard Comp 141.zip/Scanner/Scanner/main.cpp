//Drew Overgaard
//Update Scanner and Parser Project
//Comp 141

/*------------------------------------------------------------------------
I UPDATED THE SCANNER TO WORK PROPERLY FROM THE LAST PROJECT
THE PROGRAM NOW ALSO RUNS IN A LOOP
THE PARSER ONLY WORKS IF THE INPUT IS SPACED OUT SINCE I USED VECTORS
------------------------------------------------------------------------*/

#include <iostream>
#include <fstream>
#include <ctype.h>
#include <stdio.h>
#include <ctype.h>
//#include "scanner.h"
#include <String>
#include <regex>
#include <vector>
#include <string>
#include <sstream>
//Import the regex library for regular functions

using namespace std;

//void getToken(int, fstream &);
void parser(vector<string>& tokensParser, string &input, vector<string>& tokensParserVal);

int main()
{
	//string input;
	    string exit = "yes";

		while (true)
		{

			string input;
			cout << "Please enter a line. YOU MUST INCLUDE SPACES: ";
			getline(cin, input);

			if (input.length() == 0)
			{
				break;
			}

			string buf;
			stringstream ss(input);

			vector<string> tokens;
			vector<string> tokensParser;
			vector<string> tokensParserVal;

			while (ss >> buf)
				tokens.push_back(buf);

			//Testing out the vector


			/*
			for (int i = 0; i < tokens.size(); i++)
			{
			cout << tokens[i] << endl;
			}
			*/

			//	string arr[input.length];

			//I attempted to use a vector and and turn all it's elements into an array to check for specific values
			//In what the user entered into the console
			//The benifit of the array is that I can run a while loop for every char in an array
			//This, for example lets me see if there is a '.' anywhere in a string
			string arr[10000];

			copy(tokens.begin(), tokens.end(), arr);

			//Used for testing
			/*
			int iter = 0;

			while (iter < 1000)
			{
			cout << arr[iter];
			iter++;
			}
			*/

			string temp = " ";

			/*
			for (int i = 0; i < input.length(); i++)
			{
			cout << input[i] << endl;

			if (isalpha(input[i]))
			{
			cout << "SYM";
			temp += "SYM";
			}
			}
			*/



			int c = 0;
			int k = 0;
			int l = 0;
			while (c < tokens.size())
			{
				if (isalpha(arr[c][0]))   //Changed from while 
				{
					cout << "SYMBOL: " << tokens[c] << endl;
					tokensParser.push_back("SYM");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					c++;
				}
				else if (isdigit(arr[c][0]))
				{
					int z = 0;
					while (z < arr[c].length())
					{
						if (arr[c][z] == '.')
						{
							cout << "REAL: " << tokens[c] << endl;
							//c++;
							tokensParser.push_back("REAL");
							string vectorVal = tokens[c];
							tokensParserVal.push_back(vectorVal);
							c++;
						}
						z++;
					}
					/*
					cout << "INTEGER: " << tokens[c] << endl;
					c++;
					tokensParser.push_back("INT");
					*/
				}
				else if (arr[c][0] == '.' && isdigit(arr[c][1]))
				{
					cout << "REAL: " << tokens[c] << endl;
					tokensParser.push_back("REAL");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					c++;
					/*
					if (isdigit(arr[c][0]))
					{
					cout << tokens
					c++;
					}
					*/
				}

				else if (arr[c][0] == '+' && isdigit(arr[c][1]))
				{
					tokensParser.push_back("PLUS");
					int z = 0;
					while (z < arr[c].length())
					{
						if (arr[c][z] == '.')
						{
							cout << "REAL: " << tokens[c] << endl;
							tokensParser.push_back("REAL");
							string vectorVal = tokens[c];
							tokensParserVal.push_back(vectorVal);
							c++;
						}
						z++;
					}
					cout << "INTEGER: " << tokens[c] << endl;
					tokensParser.push_back("INT");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					c++;
				}
				else if (arr[c][0] == '-' && isdigit(arr[c][1]))
				{
					int z = 0;
					while (z < arr[c].length())
					{
						if (arr[c][z] == '.')
						{
							cout << "REAL: " << tokens[c] << endl;
							
							tokensParser.push_back("REAL");
							string vectorVal = tokens[c];
							tokensParserVal.push_back(vectorVal);
							c++;
						}
						z++;
					}
					
					cout << "INTEGER: " << tokens[c] << endl;
					tokensParser.push_back("INT");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					c++;
					
				}
				else if (arr[c][0] == '#' && arr[c][1] == 'f')
				{
					cout << "BOOLEAN: " << tokens[c] << endl;
					tokensParser.push_back("BOOL");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					c++;
				}
				else if (arr[c][0] == '#' && arr[c][1] == 't')
				{
					cout << "BOOLEAN: " << tokens[c] << endl;
					tokensParser.push_back("BOOL");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					c++;
				}
				else if (isdigit(arr[c][0]))
				{
					cout << "INTEGER: " << tokens[c] << endl;
					tokensParser.push_back("INT");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					c++;
				}
				else if (arr[c][0] == '-' && isdigit(arr[c][1]))
				{
					cout << "INTEGER: " << tokens[c] << endl;
					tokensParser.push_back("INT");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					c++;
				}
				else if (arr[c][0] == '+' && isdigit(arr[c][1]))
				{
					cout << "INTEGER: " << tokens[c] << endl;
					tokensParser.push_back("INT");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					c++;
				}
				else if (arr[c][0] == '(')
				{
					tokensParser.push_back("PUNC");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					int z = 0;
					while (z < arr[c].length())
					{
						if (arr[c][z] == '(')
						{
							cout << "PUNCTUATION: " << tokens[c][0] << endl;
						}
						z++;
					}
					c++;
				}
				else if (arr[c][0] == ')')
				{
					tokensParser.push_back("PUNCCLOSE");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					int z = 0;
					while (z < arr[c].length())
					{
						if (arr[c][z] == '(' || arr[c][0] == ')' || arr[c][0] == '\'')
						{
							cout << "PUNCTUATION: " << tokens[c][0] << endl;
						}
						z++;
					}
					c++;
				}
				else if (arr[c][0] == '|')
				{
					tokensParser.push_back("PUNCSLASH");
					string vectorVal = tokens[c];
					tokensParserVal.push_back(vectorVal);
					int z = 0;
					while (z < arr[c].length())
					{
						if (arr[c][0] == '|')
						{
							tokensParser.push_back("PUNCSLASH");
							string vectorVal = tokens[c];
							tokensParserVal.push_back(vectorVal);
							cout << "PUNCTUATION: " << tokens[c][0] << endl;
						}
						z++;
					}
					c++;
				}
				else if(arr[c][0] == ' ')
				{
					c++;
				}
				else
				{
					cout << "There was an error!" << endl;
					break;
				}
			}

			/*
		for (int i = 0; i < tokensParser.size(); i++)
		{
		cout << tokensParser[i] << endl;
		cout << tokensParserVal[i] << endl;
		}
		*/
			//Call the parse tree function which takes in two vectors. One vector gets the token name, while to other gets a token value
			parser(tokensParser, input, tokensParserVal);
		}
	
	//{

	
	/*
		int i = 0;
		int inc = i + 1;
		int inc2 = i + 2;
		int f = 0;
		while (f < tokens.size())
			if (input[i] ==  '+' && isdigit(input[inc]) && input[inc2] == '.')
			{
				cout << "REAL: " << tokens[f] << endl;
				f++;
				i = i + tokens[f].size();
			}
			else if (input[i] == '+' && isdigit(input[inc]))
			{
				int inc = i + 1;
				cout << "INTEGER: " << tokens[f] << endl;
				f++;
				i = i + tokens[f].size();
			}
			else if (input[i] == '-' && isdigit(input[inc]))
			{
				int inc = i + 1;
				cout << "INTEGER: " << tokens[f] << endl;
				f++;
				i = i + tokens[f].size();
			}
			else if (input[i] == '#' && input[inc] == 't')
			{
				int inc = i + 1;
				cout << "BOOLEAN: " << tokens[f] << endl;
				f++;
				i = i + tokens[f].size();
			}
			else if (input[i] == '#' && input[inc] == 'f')
			{
				int inc = i + 1;
				cout << "BOOLEAN: " << tokens[f] << endl;
				f++;
				i = i + tokens[f].size();
			}
			else if (isalpha(input[i]) || isdigit(input[i]))
			{
				cout << "SYMBOL: " << tokens[f] << endl;
				f++;
				i = i + tokens[f].size();
			}
			else if (input[i] == '(' || input[i] == ')' || input[i] == ',')
			{
				cout << "PUNCTUATION: " << input[i] << endl;
				f++;
				i = i + tokens[f].size();
			}
			f++;
			i = i + tokens[f].size();
			*/
			/*
			else
			{
				cout << "There is an error in what you entered.";
			}
			*/
	//}
	/*
	//Token const token = line;
	while (getline(myfile, line))
	{
		
		if (token == Token::SYMBOL)
		{

		}
		
	}
	*/

	//getToken(currChar, myfile);


}

/*
 void getToken(int currChar, fstream &myfile)
{
	 char ch;
	 char check = ' ';

	 //myfile << "Writing to the file" << endl;


	 while (myfile >> noskipws >> ch && ch != ' ')
	 {
		 if (ch == ' ')
		 {
			 cout << ch << endl;
		 }
		 if (isdigit(ch))
		 {
			 cout << "Symbol: " << ch << endl;
		 }
		 if (isalpha(ch))
		 {
			 cout << "Symbol: " << ch << endl;
		 }
		 if (ch == '#t' || ch == '#f')
		 {
			 cout << "Boolean: " << ch << endl;
		 }
		 if (ch == '.' && isdigit(ch))
		 {
			 cout << "Real: " << ch << endl;
		 }
		 if (ch == '(' || ch == ')' || ch == '()' || ch == ',')
		 {
			 cout << "Punctuation: " << ch << endl;
		 }
		 
	 }
}
*/

 /*
 void Scanner()
 {
	char c
 }
 */


void parser(vector<string>& tokensParser, string &input, vector<string>& tokensParserVal)
{
	cout << "----------NOW PRINTING THE PARSE TREE----------" << endl;

	string tab = "";
	for (int i = 0; i < tokensParser.size(); i++)
	{
		if (tokensParser[i] == "PUNC")
		{
			if (i == 0)
			{
				cout << tab;
				cout << tokensParserVal[i] << endl;
			}
			else
			{
				tab += "   ";
				cout << tab;
				cout << tokensParserVal[i] << endl;
			}
		}
		if (tokensParser[i] == "PUNCCLOSE")
		{
			if (i == tokensParser.size() - 1)
			{
				cout << tokensParserVal[i] << endl;
			}
			else
			{
				cout << tab;
				cout << tokensParserVal[i] << endl;
			}
		}
		if (tokensParser[i] == "PUNCSLASH")
		{
			cout << tab;
			cout << tokensParserVal[i] << endl;
		}
		if (tokensParser[i] == "SYM")
		{
			 cout << tab;
			 cout << tokensParser[i] << ":" << tokensParserVal[i] << endl;
		}
		if (tokensParser[i] == "BOOL")
		{
			cout << tab;
			cout << tokensParser[i] << ":" << tokensParserVal[i] << endl;
		}
		if (tokensParser[i] == "INT")
		{
			cout << tab;
			cout << tokensParser[i] << ":" << tokensParserVal[i] << endl;
		}
		if (tokensParser[i] == "REAL")
		{
			cout << tab;
			cout << tokensParser[i] << ":" << tokensParserVal[i] << endl;
		}
	}
}
